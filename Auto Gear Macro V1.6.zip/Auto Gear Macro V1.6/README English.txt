# 🇬🇧 English

## What is Auto Gear Macro
Auto Gear Macro is a keyboard and mouse automation tool  
designed for AFK usage and repetitive tasks with a simple GUI.

The **EXE version** runs instantly  
**No Python installation required**

---

## Features
- Automatic key pressing
- Key combinations (e.g. `Ctrl + A`)
- Hold key actions
- Mouse left / right click
- Mouse hold
- Mouse move to saved positions
- Time units: ms / sec / min
- Continuous or fixed repeat count
- Automatically stops after reaching repeat count
- Export / Import macros (`.json`)
- System Tray support
- Multi-language UI
- Low resource usage (AFK friendly)

---

## Basic Usage
1. Run `Auto Gear Macro.exe`
2. Set Start / Stop hotkey (default: F6)
3. Click **Add action** to create macro steps
4. Configure delay and repeat mode
5. Press hotkey to start or stop

---

## Mouse Move
1. Select **Mouse Move** action
2. Move mouse to target position
3. Press **F5** to capture the position

---

## System Tray
- Closing the window sends the app to the tray
- Right-click tray icon to show / start / stop / exit

---

## Notes
This software only automates OS-level input.  
Usage with games or other software depends on their policies.

---

## About
**Auto Gear Macro**  
Version: v1.6  

Support me on every social platform as **“goojabaa”**  
Powered by Lnw
